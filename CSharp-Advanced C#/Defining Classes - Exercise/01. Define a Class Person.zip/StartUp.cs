﻿using System;

namespace DefiningClasses;

public class StartUp
{
    private static void Main(string[] args)
    {
        Person person = new Person();

        person.Name = "Peter";
        person.Age = 18;

        Console.WriteLine($"{person.Name} is {person.Age} years old");


        Person george = new Person();
        {
            george.Name = "George";
            george.Age = 16;

            Console.WriteLine($"{george.Name} is {george.Age} years old");
        }
    }
}
