﻿namespace Vehicles.Core
{
    using System;
    using Interfaces;
    using IO.Interfaces;
    using Models.Interfaces;
    using Factories.Interfaces;
    using Vehicles.Exceptions;

    public class Engine : IEngine
    {
        private readonly IReader reader;
        private readonly IWriter writer;

        private readonly IVehicleFactory factory;
        private readonly ICollection<IVehicle> vehicles;

        //private IVehicle car;
        //private IVehicle truck;

        private Engine()
        {
            this.vehicles = new HashSet<IVehicle>();
        }
        public Engine(IReader reader, IWriter writer, IVehicleFactory factory)
            : this() 
        {
            this.reader = reader;
            this.writer = writer;
            this.factory = factory;
        }

        public void Run()
        {
            this.vehicles.Add(this.BuildWithFactory());
            this.vehicles.Add(this.BuildWithFactory());

            int n = int.Parse(this.reader.ReadLine());
            for(int i = 0; i < n; i++)
            {
                try
                {
                    this.ProcessCommand();
                }
                catch(InufficentFuelException ife)
                {
                    this.writer.WriteLine(ife.Message);
                }
                catch (VehicleTypeNotAvailableException vtnae)
                {
                    this.writer.WriteLine(vtnae.Message);
                }
                catch(Exception)
                {
                    throw;
                }
            }

            this.PrintVehicles();
        }

        private IVehicle BuildWithFactory()
        {
            string[] VehicleInfo = this.reader.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries);
            string vehicleType = VehicleInfo[0];
            double vehicleFuelQuantity = double.Parse(VehicleInfo[1]);
            double vehicleFuelConsumption = double.Parse(VehicleInfo[2]);

            IVehicle vehicle = 
                this.factory.CreateVehicle(vehicleType, vehicleFuelQuantity, vehicleFuelConsumption);
            return vehicle;
        }

        private void ProcessCommand()
        {
            string[] commandInfo = this.reader.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
            string commandType = commandInfo[0];
            string vehicleType = commandInfo[1];
            double argument = double.Parse(commandInfo[2]);

            IVehicle vehicleToDictate = this.vehicles
                .FirstOrDefault(v => v.GetType().Name == vehicleType);
            if (vehicleToDictate == null)
            {
                throw new VehicleTypeNotAvailableException();
            }

            if (commandType == "Drive")
            {
                this.writer.WriteLine(vehicleToDictate.Drive(argument));
            }
            else if (commandType == "Refuel")
            {
                vehicleToDictate.Refuel(argument);
            }
        }

        private void PrintVehicles()
        {
            foreach (IVehicle vehicle in this.vehicles)
            {
                this.writer.WriteLine(vehicle.ToString());
            }
        }
    }
}
