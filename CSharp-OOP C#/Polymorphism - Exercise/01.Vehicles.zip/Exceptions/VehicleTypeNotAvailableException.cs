﻿namespace Vehicles.Exceptions
{
    using System;
    public class VehicleTypeNotAvailableException : Exception
    {
        private const string DefaultMessage = "Vehicle type not supported";
        public VehicleTypeNotAvailableException()
            : base(DefaultMessage)
        {

        }

        public VehicleTypeNotAvailableException(string message)
            : base(message)
        {

        }
    }
}
