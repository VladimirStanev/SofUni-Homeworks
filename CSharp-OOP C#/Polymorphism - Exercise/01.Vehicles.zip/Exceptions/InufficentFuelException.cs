﻿namespace Vehicles.Exceptions
{
    using System;
    public class InufficentFuelException : Exception
    {
        public InufficentFuelException(string message) 
            : base(message)
        { 
        }
    }
}
