﻿namespace Vehicles
{
    using Core;
    using Core.Interfaces;
    using IO.Interfaces;
    using Factories;
    using Factories.Interfaces;
    using IO;

    internal class StartUp
    {
        static void Main(string[] args)
        {
            IReader reader = new ConsoleReader();
            IWriter writer = new ConsoleWriter();
            IVehicleFactory vehicleFactory = new VehicleFactory();

            IEngine engine = new Engine(reader, writer, vehicleFactory);
            engine.Run();
        }
    }
}