﻿namespace _01._Class_Box_Data
{
    public static class ExceptionalMessagecs
    {
        public const string BoxParameterZeroOrNegative =
            "{0} cannot be zero or negative.";
    }
}
