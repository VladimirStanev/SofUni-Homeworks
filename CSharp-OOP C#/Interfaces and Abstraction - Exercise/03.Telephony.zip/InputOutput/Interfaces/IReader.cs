﻿namespace Telephony.InputOutput.Interfaces
{
    public interface IReader
    {
        string ReadLine();
    }
}
