﻿namespace Telephony
{
    using Core;
    using Core.Interfaces;

    using Telephony.InputOutput;
    using Telephony.InputOutput.Interfaces;

    internal class StartUp
    {
        static void Main(string[] args)
        {
            IReader reader = new ConsoleReader();
            IWriter writer = new ConsoleWriter();

            IEngine engine = new Engine(reader, writer);
            engine.Run();
        }
    }
}