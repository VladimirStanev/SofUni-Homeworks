﻿namespace BorderControl
{
    using System;
    internal class StartUp
    {
        static void Main(string[] args)
        {
            List<string> listOfIds = new List<string>();

            string command = Console.ReadLine();
            while (command != "End")
            {
                string[] information = command.Split(" ");
                if (information.Count() == 3)
                {
                    string name = information[0]; //Nenko
                    int age = int.Parse(information[1]); //22
                    string id = information[2]; //82138218122

                    listOfIds.Add(id);                   
                }
                else if(information.Count() == 2)
                {
                    string model = information[0]; //MK-12
                    string id = information[1]; //33283122

                    listOfIds.Add(id);

                }
                command = Console.ReadLine();
            }

            string numberToCompareTo = Console.ReadLine();
            foreach(var id in listOfIds)
            {
                string currentId = string.Empty;
                if (id.Length > numberToCompareTo.Length)
                {
                    int howMuchToRemove = id.Length - numberToCompareTo.Length;
                    currentId = id.Remove(0, howMuchToRemove);
                    if(currentId == numberToCompareTo)
                    {
                        Console.WriteLine(id);
                    }
                }
                else
                {
                    currentId = id;
                    if (currentId == numberToCompareTo)
                    {
                        Console.WriteLine(id);
                    }
                }
            }
        }
    }
}
