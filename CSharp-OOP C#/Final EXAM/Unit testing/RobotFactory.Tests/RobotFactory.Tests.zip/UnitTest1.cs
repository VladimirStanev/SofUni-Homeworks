using NUnit.Framework;

namespace RobotFactory.Tests
{
    public class Tests
    {
        private Factory factory;

        private string name = "FactoryName";
        private int capacity = 6;

        private Robot robot;
        private string model = "Pesho";
        private double price = 300;
        private int interfaceStandard = 4;

        [SetUp]
        public void Setup()
        {
            factory = new Factory(name, capacity);
            robot = new Robot(model, price, interfaceStandard);
        }

        [Test]
        public void ConstructorTest()
        {
            Assert.AreEqual(factory.Name, name);
            Assert.AreEqual(factory.Capacity, capacity);
            Assert.AreEqual(robot.Model, model);
            Assert.AreEqual(robot.Price, price);
            Assert.AreEqual(robot.InterfaceStandard, interfaceStandard);
        }

        [Test]
        public void TestList()
        {
            Factory factory1 = new Factory("1", 3);
            Robot robot1 = new Robot("moew", 200, 2);
            factory1.Robots.Add(robot1);
            
            Assert.AreEqual(factory1.Robots.Count, 1);
        }

        [Test]
        public void SuplimentUpgrade()
        { 

        }
    }
}