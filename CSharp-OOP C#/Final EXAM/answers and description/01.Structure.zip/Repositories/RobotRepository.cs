﻿using RobotService.Models.Contracts;
using RobotService.Repositories.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobotService.Repositories
{
    public class RobotRepository : IRepository<IRobot>
    {
        private List<IRobot> robots;
        public void AddNew(IRobot model)
        {
            robots.Add(model);
        }

        public IRobot FindByStandard(int interfaceStandard)
        {
            return this.robots.FirstOrDefault(x => x.InterfaceStandards.Contains(interfaceStandard));    
        }

        public IReadOnlyCollection<IRobot> Models()
        {
            return robots.AsReadOnly();
        }

        public bool RemoveByName(string typeName)
        {
            IRobot robot = robots.FirstOrDefault(x => x.Model == typeName);
            if (robot != null)
            {
                robots.Remove(robot);
                return true;
            }

            return false;
        }
    }
}
