﻿using RobotService.Models.Contracts;
using RobotService.Repositories.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobotService.Repositories
{
    public class SupplementRepository : IRepository<ISupplement>
    {
        private List<ISupplement> supplements;

        public IReadOnlyCollection<ISupplement> Models()
        {
            return supplements.AsReadOnly();
        }

        public void AddNew(ISupplement model)
        {
            supplements.Add(model);
        }
        public bool RemoveByName(string typeName)
        {
            ISupplement supplement = supplements.FirstOrDefault(x => x.GetType().Name == typeName);
            if(supplement != null)
            {
                supplements.Remove(supplement);
                return true;
            }

            return false;
        }

        public ISupplement FindByStandard(int interfaceStandard)
        {
            ISupplement supplement = supplements.FirstOrDefault(x => x.InterfaceStandard == interfaceStandard);

            if(supplement == null)
            {
                return null;
            }

            return supplement;
        }
    }
}
