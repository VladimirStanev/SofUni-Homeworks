﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using SoftUni;
using SoftUni.Data;
using SoftUni.Models;

namespace SoftUni
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            SoftUniContext context = new SoftUniContext();

            var result = GetEmployeesInPeriod(context);
            Console.WriteLine(result);

            //6 -> //Console.WriteLine(AddNewAddressToEmployee(context));

            //5 -> //Console.WriteLine(GetEmployeesFromResearchAndDevelopment(context));

            //4 -> //Console.WriteLine(GetEmployeesWithSalaryOver50000(context));

            //3 -> //Console.WriteLine(GetEmployeesFullInformation(context));
        }

        public static string GetEmployeesInPeriod(SoftUniContext context)
        {
            var employees = context.Employees
                .Where(e => e.EmployeesProjects.Any(ep => ep.Project.StartDate.Year >= 2001 && ep.Project.StartDate.Year <= 2003))
                .Select(e => new
                {
                    FirstName = e.FirstName,
                    LastName = e.LastName,
                    ManagerFirstName = e.Manager.FirstName,
                    ManagerLastName = e.Manager.LastName,
                    Projects = e.EmployeesProjects.Select(ep => new
                    {
                        ProjectName = ep.Project.Name,
                        ProjectStartDate = ep.Project.StartDate,
                        ProjectEndDate = ep.Project.EndDate
                    })
                }).Take(10)
                .ToList();

            StringBuilder employeeManagerResult = new StringBuilder();

            foreach (var employee in employees)
            {
                employeeManagerResult.AppendLine($"{employee.FirstName} {employee.LastName} - Manager: {employee.ManagerFirstName} {employee.ManagerLastName}");

                foreach (var project in employee.Projects)
                {
                    var startDate = project.ProjectStartDate.ToString("M/d/yyyy h:mm:ss tt");
                    var endDate = project.ProjectEndDate.HasValue ? project.ProjectEndDate.Value.ToString("M/d/yyyy h:mm:ss tt") : "not finished";

                    employeeManagerResult.AppendLine($"--{project.ProjectName} - {startDate} - {endDate}");
                }
            }
            return employeeManagerResult.ToString().TrimEnd();


            //Moq variant
            //var employees = context.Employees
            //.Where(e => e.EmployeesProjects.Any(ep => ep.Project.StartDate.Year >= 2001
            //&& ep.Project.StartDate.Year <= 2023)).Take(10)
            //.Select(e => new
            //{
            //e.FirstName,
            //e.LastName,
            //ManagerFirstName = e.Manager.FirstName,
            //ManagerLastName = e.Manager.LastName,
            //Projects = e.EmployeesProjects.Select(ep => ep.Project)
            //})
            //.ToList();

            //employees.ForEach(e => Console.WriteLine($"{e.FirstName} {e.LastName} - Manager: {e.ManagerFirstName} {e.ManagerLastName}{Environment.NewLine}" +
            //$"{string.Join(Environment.NewLine, e.Projects.Select(p => $"--{p.Name} - {p.StartDate.ToString()} - {(p.EndDate == null? "not finished" : p.EndDate.ToString())}"))}"));

            //return String.Empty;
        }

        //6
        public static string AddNewAddressToEmployee(SoftUniContext context)
        {
            Address address = new Address()
            {
                AddressText = "Vitoshka 15",
                TownId = 4
            };

            var employee = context.Employees
                        .FirstOrDefault(e => e.LastName == "Nakov");

            employee.Address = address;

            context.SaveChanges();

            var employees = context.Employees
                            .Select(e => new 
                            { 
                                e.AddressId,
                                e.Address.AddressText 
                            })
                            .OrderByDescending(e => e.AddressId)
                            .Take(10)
                            .ToList();

            return String.Join(Environment.NewLine, employees.Select(e => $"{e.AddressText}"));
        }
        //5
        public static string GetEmployeesFromResearchAndDevelopment(SoftUniContext context)
        {
            var rndEmployees = context.Employees
                                .Where(e => e.Department.Name == "Research and Development")
                                .Select(e => new
                                {
                                    e.FirstName,
                                    e.LastName,
                                    e.Department.Name,
                                    e.Salary
                                })
                                .OrderBy(e => e.Salary).ThenBy(e => e.FirstName);

            //Console.WriteLine(rndEmployees.ToQueryString());

            return string.Join(Environment.NewLine, rndEmployees.Select(e => $"{e.FirstName} {e.LastName} from {e.Name} - ${e.Salary:f2}"));
        }

        //4
        public static string GetEmployeesWithSalaryOver50000(SoftUniContext context)
        {
            var employees = context.Employees
                                .Select(e => new
                                {
                                    e.FirstName,
                                    e.Salary
                                }).Where(e => e.Salary > 50000)
                                .OrderBy(e => e.FirstName)
                                .ToList();

            return string.Join(Environment.NewLine, employees.Select(e => $"{e.FirstName} - {e.Salary:f2}"));
        }

        //3
        public static string GetEmployeesFullInformation(SoftUniContext context)
        {
            var employees = context.Employees
                .Select(e => new
                {
                    e.FirstName,
                    e.LastName,
                    e.MiddleName,
                    e.JobTitle,
                    e.Salary
                }).ToList();

            string result = string.Join(Environment.NewLine, 
               employees.Select(e => $"{e.FirstName} {e.LastName} {e.MiddleName} {e.JobTitle} {e.Salary:f2}"));

            return result;
        }
    }
}