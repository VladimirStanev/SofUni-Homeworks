﻿using Microsoft.EntityFrameworkCore;
using SoftUni.Data;

namespace SoftUni
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            SoftUniContext context = new SoftUniContext();

            Console.WriteLine(GetEmployeesFromResearchAndDevelopment(context));

            //4 ->  //Console.WriteLine(GetEmployeesWithSalaryOver50000(context));

            //3 ->  //Console.WriteLine(GetEmployeesFullInformation(context));
        }

        public static string GetEmployeesFromResearchAndDevelopment(SoftUniContext context)
        {
            var rndEmployees = context.Employees
                                .Where(e => e.Department.Name == "Research and Development")
                                .Select(e => new
                                {
                                    e.FirstName,
                                    e.LastName,
                                    e.Department.Name,
                                    e.Salary
                                })
                                .OrderBy(e => e.Salary).ThenBy(e => e.FirstName);

            //Console.WriteLine(rndEmployees.ToQueryString());

            return string.Join(Environment.NewLine, rndEmployees.Select(e => $"{e.FirstName} {e.LastName} from {e.Name} - ${e.Salary:f2}"));
        }

        //4
        public static string GetEmployeesWithSalaryOver50000(SoftUniContext context)
        {
            var employees = context.Employees
                                .Select(e => new
                                {
                                    e.FirstName,
                                    e.Salary
                                }).Where(e => e.Salary > 50000)
                                .OrderBy(e => e.FirstName)
                                .ToList();

            return string.Join(Environment.NewLine, employees.Select(e => $"{e.FirstName} - {e.Salary:f2}"));
        }

        //3
        public static string GetEmployeesFullInformation(SoftUniContext context)
        {
            var employees = context.Employees
                .Select(e => new
                {
                    e.FirstName,
                    e.LastName,
                    e.MiddleName,
                    e.JobTitle,
                    e.Salary
                }).ToList();

            string result = string.Join(Environment.NewLine, 
               employees.Select(e => $"{e.FirstName} {e.LastName} {e.MiddleName} {e.JobTitle} {e.Salary:f2}"));

            return result;
        }
    }
}