--Create a stored procedure, named usp_SearchByCountry(@country) 
--that receives a country name. The procedure must print full information 
--about all vendors that have an address in the given country: 
--Name, NumberVAT, Street Name and Number (concatenated), PostCode and City (concatenated). 
--Order them by Name (ascending) and City (ascending).
--Vendor	VAT	Street Info	City Info
--LE RELAIS DES PRIMEURS	FR64431553163	Rue de la Gare 17	Taule 29670
--SARL HEBERGECO	FR75532664075	Route de Orleans 37	Evreux 27000


CREATE PROCEDURE usp_SearchByCountry
	@country VARCHAR(10)
AS
	SELECT 
		v.[Name] AS Vendor,
		v.NumberVAT AS VAT,
		CONCAT_WS(' ', a.StreetName, a.StreetNumber) AS [Street Info],
		CONCAT_WS(' ', a.City, a.PostCode) AS [City Info]
	FROM Vendors AS v
		JOIN Addresses AS a ON v.AddressId = a.Id
		JOIN Countries AS c ON a.CountryId = c.Id
	WHERE c.[Name] = @country
	ORDER BY v.[Name] ASC, a.City ASC;


-- EXEC usp_SearchByCountry 'France'