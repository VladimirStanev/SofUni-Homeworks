SELECT Number, Currency FROM Invoices ORDER BY Amount DESC, DueDate ASC;

SELECT 
	p.Id, 
	p.[Name], 
	p.Price, 
	c.[Name] AS CategoryName 
FROM Products AS p JOIN Categories AS c ON p.CategoryId = c.Id
WHERE c.[Name] IN ('ADR', 'Others')
ORDER BY p.Price DESC;

SELECT 
	c.Id, 
	c.[Name] AS Client,
	CONCAT(a.StreetName, ' ', a.StreetNumber, ', ', a.City, ', ', a.PostCode, ', ', cn.[Name]) AS [Address]
FROM Clients AS c 
	JOIN Addresses AS a ON c.AddressId = a.Id
	JOIN Countries AS cn ON a.CountryId = cn.Id
	LEFT JOIN ProductsClients AS pc ON pc.ClientId = c.Id
WHERE pc.ProductId IS NULL
ORDER BY c.[Name] ASC;

SELECT TOP 7
	i.Number,
	i.Amount,
	c.[Name] AS Client
FROM Invoices AS i JOIN Clients AS c ON i.ClientId = c.Id
WHERE 
	(i.IssueDate < '2023-01-01' AND i.Currency = 'EUR')
	OR (i.Amount > 500.00 AND c.NumberVAT LIKE 'DE%')
ORDER BY i.Number ASC, i.Amount DESC;	

SELECT 
	c.[Name] AS Client,
	MAX(p.Price) AS Price,
	c.NumberVAT AS [VAT Number]
FROM Clients AS c 
	JOIN ProductsClients AS pc ON pc.ClientId = c.Id
	JOIN Products AS p ON pc.ProductId = p.Id
WHERE c.[Name] NOT LIKE '%KG'
GROUP BY c.[Name], c.NumberVAT
ORDER BY MAX(p.Price) DESC;

SELECT 
	c.[Name] AS Client,
	FLOOR(AVG(p.Price)) AS [Average Price]
FROM Clients AS c 
	JOIN ProductsClients AS pc ON pc.ClientId = c.Id
	JOIN Products AS p ON pc.ProductId = p.Id
	JOIN Vendors AS v ON p.VendorId = v.Id AND v.NumberVAT LIKE '%FR%'
GROUP BY c.[Name]
ORDER BY FLOOR(AVG(p.Price)) ASC, c.[Name] DESC