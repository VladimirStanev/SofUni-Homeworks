--Create a user-defined function, named udf_ProductWithClients(@name) 
--that receives a product's name.
--The function should return the total number of clients that the product has been sold 

CREATE FUNCTION udf_ProductWithClients(@name NVARCHAR(35))
RETURNS INT
AS
BEGIN
	DECLARE @result INT;
	SELECT @result = COUNT(*) 
	FROM Clients AS c
		JOIN ProductsClients AS pc ON pc.ClientId = c.Id
		JOIN Products AS p ON pc.ProductId = p.Id AND p.[Name] = @name;
	IF (@result IS NULL)
		SET @result = 0;
	RETURN @result;
END;

--SELECT dbo.udf_ProductWithClients('DAF FILTER HU12103X')